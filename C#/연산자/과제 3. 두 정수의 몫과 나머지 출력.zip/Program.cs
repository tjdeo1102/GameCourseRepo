﻿namespace _3_DivideTwoInt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("나눗셈을 진행할 첫 번째 수를 입력하여 주세요:");
            bool isRight1 = int.TryParse(Console.ReadLine(), out num1);
            Console.Write("두번째 나눌 수를 입력해주세요:");
            bool isRight2 = int.TryParse(Console.ReadLine(), out num2);
            if (num2 == 0)
            {
                Console.WriteLine("0으로는 나눌 수 없습니다.");
            }
            else if (isRight1 && isRight2)
            {
                Console.WriteLine($"{num1}와 {num2}의 나눗셈 결과, 몫은 {num1 / num2} 나머지는 {num1 % num2}");
            }
            else
            {
                Console.WriteLine("잘못된 입력");
            }
        }
    }
}
