﻿namespace _2_SumTwoNumbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("첫 번째 실수를 입력하여 주세요");
            float num1, num2;
            bool is_right1 = float.TryParse(Console.ReadLine(),out num1);
            Console.WriteLine("두 번째 실수를 입력하여 주세요");
            bool is_right2 = float.TryParse(Console.ReadLine(), out num2);
            if (is_right1 && is_right2)
            {
                Console.WriteLine($"두 수의 합은 {num1 + num2}입니다");
            }
            else
            {
                Console.WriteLine("잘못된 입력");
            }
        }
    }
}
