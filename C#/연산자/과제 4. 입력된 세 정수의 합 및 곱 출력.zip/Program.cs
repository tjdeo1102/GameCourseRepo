﻿namespace _4_Sum_Mul_Three_Num
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1,num2,num3;
            Console.WriteLine("첫째 정수 입력");
            bool isRight1 = int.TryParse(Console.ReadLine(),out num1);
            Console.WriteLine("둘째 정수 입력");
            bool isRight2 = int.TryParse(Console.ReadLine(), out num2);
            Console.WriteLine("셋째 정수 입력");
            bool isRight3 = int.TryParse(Console.ReadLine(), out num3);

            if (isRight1 && isRight2 && isRight3)
            {
                Console.WriteLine($"첫째수 더하기 둘째수에 셋째수를 곱한 값은 {(num1 + num2) * num3} 입니다");
            }
            else
            {
                Console.WriteLine("잘못된 입력");
            }
        }
    }
}
